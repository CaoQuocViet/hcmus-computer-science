#pragma once

// a) Test Constructors and Conversion  
void testConstructorsAndConversion();

// b) Test Parts and Rounding
void testPartsAndRounding();

// c) Test Arithmetic
void testArithmetic();

// d) Test Comparison
void testComparison();